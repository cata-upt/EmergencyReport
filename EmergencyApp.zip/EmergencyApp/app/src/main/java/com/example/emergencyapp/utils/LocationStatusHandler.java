package com.example.emergencyapp.utils;

public interface LocationStatusHandler {
    public void onGPSDisabled();
    public void onGPSEnabled();
}
